<?php

	require("www2-funcs.php");
	login_init();
	assert_login();
	
	$filename = "tmp/bm.".$currentuser["userid"];
	if(isset($_GET["act"]))
	{
		$act = $_GET["act"];
		if($act == "clear")
		{
			@unlink($filename);
			@unlink($filename.".attach");
?>
<script type="text/javascript">
alert("�ݴ浵����ա�");
window.close();
</script>
<?php
			exit;
		}
	}
	page_header("�鿴�ݴ浵");
	$s = bbs2_readfile($filename);
	if(is_string($s))
	{
?>
<br><div class="article">
<script type="text/javascript"><!--
<?php
		print($s);
?>
//-->
</script></div>
<br>[<a href="bbsimport.php?act=clear">���</a>]<br><br>
<?php
	}
	else
	{
?>
<div align="center"><br>�ݴ浵��û�����ݡ�<br><br></div>
<?php
	}
	page_footer();

?>