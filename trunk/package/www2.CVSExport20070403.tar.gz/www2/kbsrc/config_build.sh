#!/bin/bash

# Build config for the build script, build.sh. Look there for more info.

APP_NAME=kbsrc
CHROME_PROVIDERS="content locale skin"
CLEAN_UP=1
ROOT_FILES=
ROOT_DIRS=
BEFORE_BUILD=
AFTER_BUILD=
