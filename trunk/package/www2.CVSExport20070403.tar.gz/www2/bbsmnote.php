<?php
	require("www2-funcs.php");
	login_init();
	bbs_session_modify_user_mode(BBS_MODE_EDITUFILE);
	$usernum = $currentuser["index"];
	if (isset($_GET["board"]))
		$board = $_GET["board"];
	else 
		html_error_quit("�����������");

	$brdarr = array();
	$brdnum = bbs_getboard($board, $brdarr);
	if ($brdnum == 0)
		html_error_quit("�����������");
	if (!bbs_is_bm($brdnum,$usernum))
		html_error_quit("�㲻�ǰ���");
	$top_file="vote/" . $board . "/notes";
	if (isset($_POST["text"])) {
		$fp = @fopen($top_file, "w");
		if ($fp==FALSE) {
			html_error_quit("�޷����ļ�");
		} else {
			$data=$_POST["text"];
			fwrite($fp,str_replace("\r\n","\n",$data));
			fclose($fp);
			html_success_quit("�޸ı���¼�ɹ�!<br/><a href=\"bbsdoc.php?board=" . $board . "\">��������</a>");
		}
	}
	bbs_board_nav_header($brdarr, "����¼�༭");
?>
<form method="post" action=<?php echo "\"bbsmnote.php?board=" . $board . "\""; ?> class="large">
<fieldset><legend>�޸Ľ��滭��</legend>
<textarea name="text" onkeydown='return textarea_okd(this, event);' wrap="physical" id="sfocus">
<?php
    echo @htmlspecialchars(file_get_contents($top_file));
?>
</textarea>
</fieldset>
<div class="oper">
<input type="submit" value="����" /> <input type="reset" value="��ԭ" />
</div>
</form>
<?php
	page_footer();
?>
