<?php
	require("www2-funcs.php");
	login_init();
	bbs_session_modify_user_mode(BBS_MODE_GMENU);
	toolbox_header("��������");
	assert_login();

	if( isset( $_GET["start"] ) ){
		$start = $_GET["start"];
		settype($start, "integer");
	}else
		$start = 0;

	$total = bbs_countfriends($currentuser["userid"]);

	if( $total < 0 ) html_error_quit("ϵͳ����");

	if( $total != 0 ){
		if($start >= $total){
			$start = $total - 20;
			if($start < 0) $start = 0;
		}else if($start < 0){
			$start = $total - 20;
			if($start < 0) $start = 0;
		}

		$friends = bbs_getfriends($currentuser["userid"], $start);
		if ($friends === FALSE){
			html_error_quit("ϵͳ����1");
		}
?>
<table class="main adj">
<col class="center"/><col/><col/><col class="center"/>
<caption>�������� (�� <?php echo $total;?> λ����)</caption>
<tbody>
<tr><th>���</th><th>���Ѵ���</th><th>����˵��</th><th>ɾ������</th></tr>
<?php
		$i=0;
		
		foreach ($friends as $friend){
			$i++;
?>
<tr><td><?php echo $start+$i;?></td>
<td><a href="bbsqry.php?userid=<?php echo $friend["ID"];?>"><?php echo $friend["ID"];?></a></td>
<td><?php echo $friend["EXP"];?></td>
<td>[<a onclick="return confirm('ȷʵɾ����?')" href="bbsfdel.php?userid=<?php echo $friend["ID"];?>">ɾ��</a>]</td>
</tr>
<?php
		}
?>
</tbody></table>
<?php
	}
?>
<div class="oper">
[<a href="bbsfadd.php">�����µĺ���</a>]
<?php
		if( $start > 0 ){
?>
[<a href="bbsfall.php?start=0">��һҳ</a>]
[<a href="bbsfall.php?start=<?php if($start > 20) echo $start - 20; else echo "0";?>">��һҳ</a>]
<?php
		}
		if( $start < $total - 20 ){
?>
[<a href="bbsfall.php?start=<?php echo $start + 20; ?>">��һҳ</a>]
[<a href="bbsfall.php?start=-1">���һҳ</a>]
<?php
		}
?>
</div>
<?php
		page_footer();
?>
