<?php

	require("www2-funcs.php");
	login_init();
	bbs_session_modify_user_mode(BBS_MODE_READING);
	assert_login();

		if(isset($_POST["board"]))
			$board = $_POST["board"];
		else if(isset($_GET["board"]))
			$board = $_GET["board"];
		else
			html_error_quit("��������1");

		if(isset($_POST["submit"])){
			if(isset($_POST["type"]))
				$type = $_POST["type"];
			else
				html_error_quit("��������2");

			settype($type,"integer");
			if($type < 1 || $type > 5)
				html_error_quit("��������3");

			if(isset($_POST["title"]))
				$title = $_POST["title"];
			else
				html_error_quit("��������5");

			if(isset($_POST["desp"]))
				$ball_desp = $_POST["desp"];
			else
				$ball_desp = "��ͶƱ��ʱû������";

			if(isset($_POST["numlogin"])){
				$numlogin = $_POST["numlogin"];
				settype($numlogin,"integer");
				if($numlogin < 0)
					$numlogin = 0;
			}
			else
				$numlogin = 0;

			if(isset($_POST["numpost"])){
				$numpost = $_POST["numpost"];
				settype($numpost,"integer");
				if($numpost < 0)
					$numpost = 0;
			}
			else
				$numpost = 0;

			if(isset($_POST["numstay"])){
				$numstay = $_POST["numstay"];
				settype($numstay,"integer");
				if($numstay < 0)
					$numstay = 0;
			}
			else
				$numstay = 0;

			if(isset($_POST["numday"])){
				$numday = $_POST["numday"];
				settype($numday,"integer");
				if($numday < 0)
					$numday = 0;
			}
			else
				$numday = 0;

			if(isset($_POST["maxdays"])){
				$ball_maxdays = $_POST["maxdays"];
				settype($ball_maxdays,"integer");
				if($ball_maxdays <=0)
					$ball_maxdays = 1;
			}
			else
				$ball_maxdays = 1;

			if($title == "")
				html_error_quit("��������6");

			$items = array();
			for($i = 0; $i < 31; $i ++)
				$items[$i] = "";
			$ball_maxtkt = 1;
			$ball_totalitems = 3;

			if($type == 1){
				//�Ƿ�
			}else if($type == 2 || $type == 3){
				//��ѡ,��ѡ

				if(isset($_POST["maxitems"]))
					$ball_totalitems = $_POST["maxitems"];
				else
					html_error_quit("��������5");

				settype($ball_totalitems,"integer");
				if( $ball_totalitems <= 0 || $ball_totalitems > 32)
					html_error_quit("��������5");

				if($type == 2)
					$ball_maxtkt = 1;
				else{
					if(isset($_POST["maxtkt"]))
						$ball_maxtkt = $_POST["maxtkt"];
					else
						html_error_quit("����Ĳ���4");

					settype($ball_maxtkt,"integer");
					if($ball_maxtkt <= 0)
						$ball_maxtkt = 1;
				}

				for($i = 0; $i < $ball_totalitems; $i ++){
					$itemstr = "ITEM".($i+1);
					if(isset($_POST[$itemstr])){
						$items[$i] = $_POST[$itemstr];
					}
				}
			}else if($type == 4){
				if(isset($_POST["maxnumin"]))
					$ball_maxtkt = $_POST["maxnumin"];
				else
					html_error_quit("����Ĳ���6");

				settype($ball_maxtkt,"integer");
				if($ball_maxtkt <= 0)
					$ball_maxtkt = 100;

			}

			$ret = bbs_start_vote($board, $type, $numlogin, $numpost, $numstay, $numday, $title, $ball_desp, $ball_maxdays, $ball_maxtkt, $ball_totalitems, $items[0], $items[1], $items[2], $items[3], $items[4], $items[5], $items[6], $items[7], $items[8], $items[9]);

			if($ret <= 0)
				html_error_quit("��ͶƱ����.".$ret);
			else{
				html_success_quit("��ͶƱ�ɹ�<br/><a href='bbsdoc.php?board=" . $board . "'>���ر�������</a>");
			}
		}
		
	$usernum = $currentuser["index"];
	$brdarr = array();
	$brdnum = bbs_getboard($board, $brdarr);
	if ($brdnum == 0)
		html_error_quit("�����������");
	if (!bbs_is_bm($brdnum,$usernum))
		html_error_quit("�㲻�ǰ���");
	bbs_board_nav_header($brdarr, "�¿�ͶƱ");
?>
<script type="text/javascript">
<!--//
var maxitemnum=10;
var defaultitem=3;
function doGenerate(){
	var oSelectType=document.getElementById("oType");
	var type=oSelectType.value;
	var targetDiv=document.getElementById("oDiv");
	var content="";
	var i;
	if  ( (type=="2")  || (type=="3") ){
		content+="ѡ�����:<select name=\"maxitems\" class=\"input\"  style=\"WIDTH: 60px\" id=\"oItemNum\" onChange=\"doGenerateItem();\">";
		for (i=1;i<=maxitemnum;i++){
			if (i==defaultitem){
				content+="<option value=\""+i+"\" selected>"+i+"</option>";
			}else {
				content+="<option value=\""+i+"\">"+i+"</option>";
			}
		}
		content+="</select><BR>";
		if (type=="3") {
			content+="�û�������ѡ�����:<input type=\"text\" name=\"maxtkt\" value=\"1\"><br>"
		}
		targetDiv.innerHTML=content;
		doGenerateItem();
	}else {
		if (type=="4") {
			content="��������޶�:<input type=\"text\" name=\"maxnumin\" value=\"1\"><br>";
			
		} else {
			content="<BR>";
		}
		targetDiv.innerHTML=content;
		clearItem();
	}

	return;
}


function doGenerateItem(){
	var objItemNum=document.getElementById("oItemNum");
	var itemNum=parseInt(objItemNum.value);
	var targetDiv=document.getElementById("oDivItems");
	var content="";
	var i;
	for (i=1;i<=itemNum;i++){
			content+=i+":<input type=\"text\" name=\"ITEM"+i+"\" value=\"\"><br>";
	}
	targetDiv.innerHTML=content;
	return;
}

function clearItem(){
	var oTargetDiv=document.getElementById("oDivItems");
	oTargetDiv.innerHTML="<BR>";
}

//-->
</script>
<form action="bbsmvote.php" method="post" class="large">
<input type="hidden" name="board" value="<?php echo $board;?>">
ѡ��ͶƱ����:
<select name="type" class="input"  style="WIDTH: 60px" id="oType" onChange="doGenerate();">
<option value="1">�Ƿ�</option>
<option value="2">��ѡ</option>
<option value="3">��ѡ</option>
<option value="4">����</option>
<option value="5">�ʴ�</option>
</select>
<hr class="default">
ͶƱ����:<input type="text" name="title" value=""><br>
ͶƱ����:<textarea name="desp" rows=10 cols=80 wrap="physical"></textarea><br>
ͶƱ��������:<input type="text" name="maxdays" value="1"><br>
<hr class="default">
<div id="oDiv">
</div>
<br>
<div id="oDivItems">
</div>

<hr class="default">
����ͶƱ�ʸ�ѡ��:<br>
��վ��������:<input type="text" name="numlogin" value="0"><br>
����������Ŀ����:<input type="text" name="numpost" value="0"><br>
��վ��ʱ������:<input type="text" name="numstay" value="0"><br>
�ʺ�ע��ʱ������:<input type="text" name="numday" value="0"><br>
<hr class="default">
<center>
<input type="submit" name="submit" value="ȷ��">
[<a href="javascript:history.go(-1)">���ٷ���</a>]
</form>
</center>
