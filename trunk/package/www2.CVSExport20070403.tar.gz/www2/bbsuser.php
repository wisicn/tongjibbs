<?php
	require("www2-funcs.php");

	if (defined("SITE_SMTH")) // ���ṩ�����û��б� add by windinsn, May 5,2004
		exit ();

	login_init();
	bbs_session_modify_user_mode(BBS_MODE_LUSERS);
	page_header("�����û��б�");
	
	if( isset( $_GET["start"] ) ){
		$start=$_GET["start"];
	} else {
		$start=1;
	}
	if ($start<=0) $start=1;
	$num=20;
	$users = bbs_getonline_user_list($start,$num);
	if ($users == 0)
		$count = 0;
	else
		$count = count($users);

?>
<table class="main adj">
<col class="center"/><col/><col/><col/><col/><col/><col class="right"/>
<tbody>
<tr><th>���</th><th>��</th><th>ʹ���ߴ���</th><th>ʹ�����ǳ�</th><th>����</th><th>��̬</th><th>����</th></tr>
<?php
		for($i = 0; $i < $count; $i++) {
			$mode = $users[$i]["mode"];
			if ($users[$i]["pid"] == 1) $mode = "<span class='blue'>" . $mode . "</span>";
			echo "<tr><td>" . ($i+$start) . "</td>";
			echo "<td>" . ($users[$i]["isfriend"]?"��" : "  ") . "</td>";
			echo "<td><a href=\"bbsqry.php?userid=" . $users[$i]["userid"] . "\">" . $users[$i]["userid"] . "</a></td>";
			echo "<td><a href=\"bbsqry.php?userid=" . $users[$i]["userid"] . "\"><script type=\"text/javascript\"><!--\nprints('" . str_replace("\033", "\\r", $users[$i]["username"]) . "');\n--></script></a></td>";
			echo "<td>" . $users[$i]["userfrom"] . "</td>";
			echo "<td>" . $mode . "</td>";
			echo "<td>" . ($users[$i]["idle"]!=0?$users[$i]["idle"]:" ") . "</td></tr>\n";
		}
?>
</tbody></table>
<div class="oper">
[<a href="bbsfriend.php">���ߺ���</a>]
<?php
	$prev = $start - $num;
	if ($prev <= 0) $prev = 1;
	if( $prev < $start ){
?>
[<a href="bbsuser.php?start=<?php echo $prev;?>">��һҳ</a>]
<?php
	}
	if( $count >= $num ){
?>
[<a href="bbsuser.php?start=<?php echo $start+$num;?>">��һҳ</a>]
<?php
	}
?>
</div>
<form method="GET">
<input type="submit" value="��ת����"> <input type="input" size="4" name="start"> ��ʹ����
</form><br />
<?php 
	page_footer();
?>
