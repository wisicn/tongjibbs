<?php
	require("../funcs.php");
?>