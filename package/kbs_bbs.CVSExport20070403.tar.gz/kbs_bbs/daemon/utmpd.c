#include <stdlib.h>

start_daemon()
{

}

main()
{
}
