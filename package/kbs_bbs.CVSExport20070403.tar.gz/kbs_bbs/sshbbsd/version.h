#define SSH_VERSION     "1.0.0(SMTH)"
