#ifndef GameDrawFunctionHeader
#define GameDrawFunctionHeader

void DrawElement(int x, int y, int type);
void DrawCell(int x, int y);

void DrawPad(void);
void DrawData(void);

#endif
