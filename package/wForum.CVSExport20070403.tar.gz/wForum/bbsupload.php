wForum doesn't have this function.
